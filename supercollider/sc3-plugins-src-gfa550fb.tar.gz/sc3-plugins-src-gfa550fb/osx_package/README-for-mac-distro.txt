
  -------------------------------------------------------
    sc3-plugins
    Community collection of plugins for SuperCollider 3
    http://sourceforge.net/projects/sc3-plugins/
  -------------------------------------------------------


SYSTEM REQUIREMENTS:

  These plugins should work with any Mac running OSX 10.4 or later. For builds
  for other systems (10.3, Linux, Windows) or for source code, see the website.

  Of course, you'll need SuperCollider 3 in order to use these plugins.


HOW TO INSTALL:

  On Mac, copy/move this whole folder-full of stuff to the location

          /Library/Application Support/SuperCollider/Extensions

  (This installs them for all users. Alternatively you can install them in
  a similar place in a single user's Library folder.)


COPYRIGHT:

  These plugins inherit SC3's licensing conditions, meaning you are free to
  use and redistribute them under the terms of the GNU General Public Licence,
  version 2 or later. (GPLv2 is included here as "licence.txt")

  The plugins are created by many different authors - please see the
  notices in the source/help files for information on authorship.
