<html>
<head><title>SuperCollider plugins</title>
<style type="text/css">
body { background-color: rgb(204, 204, 204); font-family: Arial,Helvetica,sans-serif; }
h1 {font-family: Arial,Helvetica,sans-serif; font-weight: normal;}

.readonlinelink {font-size: smaller; color: rgb(102,102,102); }

li              { list-style-type: none; clear: both;}
ul.grouplist    { width: 90%; clear: both; list-style-type: none; }
ul.grouplist li { width: 25%; float: left;  clear: none;}
</style>
</head>
<body>
<h1>UGen plugins for <a href="http://supercollider.github.io/">SuperCollider</a></h1>

<p>SuperCollider &quot;UGen&quot; plugins are extensions for the <a href="http://supercollider.github.io/">SuperCollider</a> audio synthesis server.</p>

<p style="margin: 30px; padding: 30px; border: 1px solid black;">Downloads are available from <a href="https://github.com/supercollider/sc3-plugins/releases">https://github.com/supercollider/sc3-plugins/releases</a>

<p style="margin: 30px; padding: 30px; border: 1px solid black;"><a href="https://github.com/supercollider/sc3-plugins">Source code is on github</a></p>



</body></html>
